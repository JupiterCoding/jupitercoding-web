import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function Impressum() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="text-2xl font-bold text-primary">JupiterCoding</div>
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="text-foreground hover:text-primary"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-32 pb-24">
        <div className="container max-w-3xl">
          <h1 className="text-5xl font-bold mb-12">Impressum</h1>

          {/* Angaben zum Verantwortlichen */}
          <div className="glass-effect p-8 rounded-lg neon-border mb-8">
            <h2 className="text-2xl font-bold mb-4 text-primary">Angaben zum Verantwortlichen</h2>
            <div className="space-y-3 text-muted-foreground">
              <p>
                <strong>Name:</strong> [Ihr Name]
              </p>
              <p>
                <strong>Adresse:</strong> [Ihre Straße und Hausnummer]<br />
                [Postleitzahl] [Ihre Stadt]<br />
                [Ihr Land]
              </p>
              <p>
                <strong>E-Mail:</strong> <a href="mailto:info@jupitercoding.de" className="text-primary hover:underline">info@jupitercoding.de</a>
              </p>
              <p>
                <strong>Telefon:</strong> [Ihre Telefonnummer]
              </p>
            </div>
          </div>

          {/* Haftungsausschluss */}
          <div className="glass-effect p-8 rounded-lg neon-border mb-8">
            <h2 className="text-2xl font-bold mb-4 text-primary">Haftungsausschluss</h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Die Inhalte unserer Seiten wurden mit größter Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte können wir jedoch keine Gewähr übernehmen. Als Diensteanbieter sind wir gemäß § 7 Abs. 1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 des TMG sind wir als Diensteanbieter jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
              </p>
              <p>
                Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen bleiben hiervon unberührt. Eine diesbezügliche Haftung ist jedoch erst ab dem Zeitpunkt der Kenntnis einer konkreten Rechtsverletzung möglich.
              </p>
            </div>
          </div>

          {/* Haftung für Links */}
          <div className="glass-effect p-8 rounded-lg neon-border mb-8">
            <h2 className="text-2xl font-bold mb-4 text-primary">Haftung für Links</h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Unsere Website enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich. Die verlinkten Seiten wurden zum Zeitpunkt der Verlinkung auf mögliche Rechtsverstöße überprüft. Rechtswidrige Inhalte waren zum Zeitpunkt der Verlinkung nicht erkennbar.
              </p>
              <p>
                Eine permanente inhaltliche Kontrolle der verlinkten Seiten ist jedoch ohne konkrete Anhaltspunkte einer Rechtsverletzung nicht zumutbar. Bei Bekanntwerden von Rechtsverletzungen werden wir derartige Links umgehend entfernen.
              </p>
            </div>
          </div>

          {/* Urheberrecht */}
          <div className="glass-effect p-8 rounded-lg neon-border mb-8">
            <h2 className="text-2xl font-bold mb-4 text-primary">Urheberrecht</h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des Autors oder Schöpfers. Downloads und Kopien dieser Seite sind nur für den privaten, nicht kommerziellen Gebrauch gestattet.
              </p>
              <p>
                Soweit die Inhalte auf dieser Seite nicht von uns erstellt wurden, werden die Urheberrechte Dritter beachtet. Insbesondere werden Inhalte Dritter als solche gekennzeichnet. Sollten Sie trotzdem auf eine Urheberrechtsverletzung aufmerksam werden, bitten wir um einen entsprechenden Hinweis. Bei Bekanntwerden von Rechtsverletzungen werden wir derartige Inhalte umgehend entfernen.
              </p>
            </div>
          </div>

          {/* Datenschutz */}
          <div className="glass-effect p-8 rounded-lg neon-border mb-8">
            <h2 className="text-2xl font-bold mb-4 text-primary">Datenschutz</h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Die Nutzung unserer Website ist in der Regel ohne Angabe personenbezogener Daten möglich. Soweit auf unseren Seiten personenbezogene Daten (beispielsweise Name, Anschrift oder E-Mail-Adressen) erhoben werden, erfolgt dies, soweit möglich, stets auf freiwilliger Basis. Diese Daten werden ohne Ihre ausdrückliche Zustimmung nicht an Dritte weitergegeben.
              </p>
              <p>
                Wir weisen darauf hin, dass die Datenübertragung im Internet (z.B. bei der Kommunikation per E-Mail) Sicherheitslücken aufweisen kann. Ein lückenloses Schützen der Daten vor dem Zugriff durch Dritte ist nicht möglich.
              </p>
              <p>
                Der Nutzung von im Rahmen der Impressumspflicht veröffentlichten Kontaktdaten durch Dritte zur Übersendung von nicht angeforderten Werbung und Informationsmaterialien wird hiermit ausdrücklich widersprochen. Die Betreiber der Seiten behalten sich ausdrücklich rechtliche Schritte im Falle der unverlangten Zusendung von Werbeinformationen, etwa durch Spam-Mails, vor.
              </p>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="glass-effect p-8 rounded-lg neon-border">
            <h2 className="text-2xl font-bold mb-4 text-primary">Disclaimer</h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                JupiterCoding übernimmt keine Haftung für die Korrektheit, Genauigkeit, Aktualität, Zuverlässigkeit und Vollständigkeit der Informationen. Haftungsansprüche gegen JupiterCoding, die sich auf Schäden materieller oder ideeller Art beziehen, welche durch die Nutzung oder Nichtnutzung der dargebotenen Informationen bzw. durch die Nutzung fehlerhafter und unvollständiger Informationen verursacht wurden, sind grundsätzlich ausgeschlossen, sofern seitens JupiterCoding kein nachweislich vorsätzliches oder grob fahrlässiges Verschulden vorliegt.
              </p>
            </div>
          </div>

          {/* Back Button */}
          <div className="mt-12 text-center">
            <Button
              onClick={() => navigate("/")}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Zurück zur Startseite
            </Button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-12 bg-card border-t border-border">
        <div className="container text-center text-sm text-muted-foreground">
          <p>&copy; 2026 JupiterCoding. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
