import { Button } from "@/components/ui/button";
import { ArrowRight, Code2, Smartphone, Zap } from "lucide-react";
import { Link } from "wouter";

const BANNER_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663111716143/Xg7BsJsmkG8mK25mhLSEU7/jupitercoding_header_4096x2304_04ad5d89.webp";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="text-2xl font-bold text-primary">JupiterCoding</div>
          <div className="hidden md:flex gap-8">
            <a href="#about" className="text-foreground hover:text-primary transition-colors">
              About
            </a>
            <a href="#apps" className="text-foreground hover:text-primary transition-colors">
              Apps
            </a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors">
              Contact
            </a>
            <Link href="/impressum">
              <a className="text-foreground hover:text-primary transition-colors">
                Impressum
              </a>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section with Banner Background */}
      <section className="relative pt-32 pb-24 md:pb-40 overflow-hidden">
        {/* Banner Background */}
        <div
          className="absolute inset-0 -z-10 bg-cover bg-center"
          style={{
            backgroundImage: `url('${BANNER_URL}')`,
          }}
        >
          {/* Dark overlay for text readability */}
          <div className="absolute inset-0 bg-black/50"></div>
        </div>

        <div className="container relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight text-white drop-shadow-lg">
              Software Development
              <span className="text-primary"> & Web Solutions</span>
            </h1>
            <p className="text-xl text-gray-100 mb-8 max-w-2xl leading-relaxed drop-shadow-md">
              JupiterCoding is a modern app development studio specializing in creating innovative Android applications and web solutions that solve real-world problems.
            </p>
            <div className="flex gap-4 flex-wrap">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 glow-cyan"
              >
                Get Started <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary text-white hover:bg-primary/10 bg-black/30"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>

        {/* Diagonal cut divider */}
        <div
          className="absolute bottom-0 left-0 right-0 h-32 bg-card"
          style={{
            clipPath: "polygon(0 30%, 100% 0, 100% 100%, 0 100%)",
          }}
        ></div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-card relative">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                About <span className="text-primary">JupiterCoding</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-4 leading-relaxed">
                We are a team of passionate developers dedicated to creating high-quality Android applications and web solutions. Our mission is to transform ideas into powerful, user-friendly digital products.
              </p>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                With expertise in modern development practices, we focus on performance, security, and user experience. Every project we build is crafted with precision and attention to detail.
              </p>
              <div className="flex gap-6">
                <div className="flex items-start gap-3">
                  <Code2 className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold mb-1">Clean Code</h3>
                    <p className="text-sm text-muted-foreground">Maintainable and scalable solutions</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Zap className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold mb-1">Performance</h3>
                    <p className="text-sm text-muted-foreground">Optimized for speed and efficiency</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="glass-effect p-8 rounded-lg neon-border">
                <div className="space-y-4">
                  <div className="h-32 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg flex items-center justify-center">
                    <Smartphone className="w-16 h-16 text-primary/50" />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Specializing in Android app development with cutting-edge technologies and best practices.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Diagonal cut divider */}
        <div
          className="absolute bottom-0 left-0 right-0 h-32 bg-background"
          style={{
            clipPath: "polygon(0 0, 100% 30%, 100% 100%, 0 100%)",
          }}
        ></div>
      </section>

      {/* Apps Portfolio Section */}
      <section id="apps" className="py-24 bg-background relative">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-center">
            Our <span className="text-primary">Applications</span>
          </h2>
          <p className="text-center text-muted-foreground mb-16 max-w-2xl mx-auto">
            Discover the applications we've developed to solve real-world problems and enhance user productivity.
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Simple Browser App */}
            <div className="glass-effect p-8 rounded-lg neon-border hover:glow-cyan transition-all duration-300 hover:scale-105">
              <div className="mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center mb-4">
                  <Code2 className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl font-bold mb-2">Simple Browser</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  A lightweight and fast web browser for Android with essential features and a clean interface.
                </p>
              </div>
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-2 h-2 bg-primary rounded-full"></span>
                  <span>Fast and responsive browsing</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-2 h-2 bg-primary rounded-full"></span>
                  <span>Minimal resource usage</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-2 h-2 bg-primary rounded-full"></span>
                  <span>Privacy-focused design</span>
                </div>
              </div>
              <Button
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => window.open("https://play.google.com", "_blank")}
              >
                View on Play Store
              </Button>
            </div>

            {/* PDF Viewer Pro App */}
            <div className="glass-effect p-8 rounded-lg neon-border hover:glow-cyan transition-all duration-300 hover:scale-105">
              <div className="mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-secondary to-primary rounded-lg flex items-center justify-center mb-4">
                  <Smartphone className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl font-bold mb-2">PDF Viewer Pro</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  A powerful PDF viewer for Android with advanced features for document management and annotation.
                </p>
              </div>
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-2 h-2 bg-primary rounded-full"></span>
                  <span>Advanced PDF rendering</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-2 h-2 bg-primary rounded-full"></span>
                  <span>Annotation tools</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-2 h-2 bg-primary rounded-full"></span>
                  <span>Coming soon on Play Store</span>
                </div>
              </div>
              <Button
                className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90"
                disabled
              >
                Coming Soon
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-24 bg-card relative">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Build Something <span className="text-primary">Amazing?</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Get in touch with us to discuss your project and how we can help bring your ideas to life.
          </p>
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 glow-cyan"
          >
            Contact Us <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>

        {/* Diagonal cut divider */}
        <div
          className="absolute bottom-0 left-0 right-0 h-32 bg-background"
          style={{
            clipPath: "polygon(0 0, 100% 30%, 100% 100%, 0 100%)",
          }}
        ></div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-background border-t border-border">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">JupiterCoding</h3>
              <p className="text-sm text-muted-foreground">
                Software Development and Web Solutions
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#apps" className="hover:text-primary transition-colors">Apps</a></li>
                <li><a href="#about" className="hover:text-primary transition-colors">About</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/impressum"><a className="hover:text-primary transition-colors">Impressum</a></Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Connect</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">GitHub</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Twitter</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 JupiterCoding. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
