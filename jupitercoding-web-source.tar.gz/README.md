# JupiterCoding - Software Development and Web Solutions

A modern, futuristic website for JupiterCoding, an Android app development studio specializing in creating innovative applications and web solutions.

## Features

- **Futuristic Minimalist Design**: Dark theme with neon cyan and purple accents
- **Responsive Layout**: Optimized for desktop, tablet, and mobile devices
- **App Portfolio**: Showcase of developed applications (Simple Browser, PDF Viewer Pro)
- **Impressum Page**: Complete legal information and disclaimers
- **Modern Tech Stack**: React 19, Tailwind CSS 4, TypeScript

## Project Structure

```
jupitercoding-web/
├── client/
│   ├── src/
│   │   ├── pages/          # Page components (Home, Impressum)
│   │   ├── components/     # Reusable UI components
│   │   ├── contexts/       # React contexts (Theme)
│   │   ├── App.tsx         # Main app component with routing
│   │   ├── main.tsx        # React entry point
│   │   └── index.css       # Global styles with design tokens
│   ├── index.html          # HTML template
│   └── public/             # Static assets
├── package.json            # Project dependencies
├── vite.config.ts          # Vite configuration
└── tsconfig.json           # TypeScript configuration
```

## Design Philosophy

The website follows a **Futuristic Minimalist** design approach:

- **Color Scheme**: Dark background (#0a0e27) with neon cyan (#00d9ff) and electric purple (#b300ff) accents
- **Typography**: Space Mono for headlines (bold, technical), Inter for body text (readable, modern)
- **Layout**: Asymmetric structures with diagonal cuts and glass-morphism effects
- **Animations**: Smooth transitions, parallax effects, and glow animations

## Getting Started

### Prerequisites

- Node.js 18+
- pnpm (recommended) or npm

### Installation

```bash
# Install dependencies
pnpm install

# Start development server
pnpm run dev

# Build for production
pnpm run build

# Preview production build
pnpm run preview
```

## Technologies Used

- **React 19** - UI library
- **Tailwind CSS 4** - Utility-first CSS framework
- **TypeScript** - Type-safe JavaScript
- **Vite** - Fast build tool and dev server
- **Wouter** - Lightweight routing library
- **shadcn/ui** - High-quality UI components
- **Lucide React** - Beautiful icon library

## Pages

- **Home** (`/`) - Landing page with hero section, about section, app portfolio, and CTA
- **Impressum** (`/impressum`) - Legal information and disclaimers

## Deployment

The website is deployed on GitHub Pages and can be accessed at:
`https://jupitercoding.github.io/jupitercoding-web/`

## License

MIT

## Contact

For inquiries, please reach out to: info@jupitercoding.de
